const router=require('express').Router();
const bodyParser=require('body-parser');
const bcrypt=require('bcryptjs');
const{check,validationResult}=require('express-validator');
const User=require('./../models/user');

//MIDDLEWARE

router.use(bodyParser.json());
router.use(bodyParser.urlencoded({extended:true}));

router.all('/',function(req,res){
    return res.json({
        Status:true,
        message:'User Controller Working'
    });
});
