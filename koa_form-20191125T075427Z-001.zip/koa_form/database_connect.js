const mongoose=require('mongoose');
const assert=require('assert');
mongoose.connect(process.env.DB_URL,
    {   useNewUrlParser:true,
        useUnifiedTopology:true,
        useCreateIndex:true
    },function(error,link){
    assert.equal(error,null);
    console.log('DB CONNECT');
    console.log(link);
})