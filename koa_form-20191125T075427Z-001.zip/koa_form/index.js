const koa=require('koa');
const app=new koa();
const koaRouter=require('koa-router');
const router=new koaRouter();
const serve=require('koa-static');

app.use(router.routes()).use(router.allowedMethods());

//app.use(async ctx=>ctx.body="hello");
//router.get('/',createUser);
app.listen(3000,()=>{console.log('server start')});
/*function *createUser()
{
    this.redirect('index.html');
}*/

router.get("/", async(ctx, next) => 
  serve(`${__dirname}/public`)(
    Object.assign(ctx, { path: 'index.html' }), 
    next)
);
