const koa = require("koa");
const app = new koa();
const koaRouter = require("koa-router");
const router = new koaRouter();
const serve = require("koa-static");
const bodyParser = require("koa-body");
require("dotenv").config();
const database = require("./database_connect.js");
const bcrypt = require("bcryptjs");
const datalize = require("datalize");
const field = datalize.field;
const User = require("./models/user.js");
var formidable = require("koa2-formidable");

app.use(formidable({}));

app.use(router.routes()).use(router.allowedMethods());

//app.use(async ctx=>ctx.body="hello");
//router.get('/',createUser);

app.listen(3000, () => {
  console.log("server start");
});

app.use(
  bodyParser({
    enableTypes: ["json", "form"],
    multipart: true,
    urlencode: true
  })
);

router.get("/", async (ctx, next) =>
  serve(`${__dirname}/public`)(Object.assign(ctx, { path: "index.html" }),next)
);

router.post(
  "/signup",
  datalize([
    field("email")
      .required()
      .email(),
    field("password")
      .required()
      .length(8, 15)
      .trim()
      .custom(function(value, result, ctx) {
        console.log(ctx.request.body.confirm_password);
        console.log(value);
        if (value !== ctx.request.body.confirm_password) {
          throw new Error("Passwords don't match");
        } else {
          return value;
        }
      }),
    field("confirm_password")
      .required()
      .length(8, 15)
      .trim()
  ]),
  async ctx => {
    if (!ctx.form.isValid) {
      ctx.status = 400;
      ctx.body = {
        status: "error",
        message: "Form Validation Error",
        errors: ctx.form.errors
      };
      return;
    }
    ctx.body = {
      status: "success",
      message: "Correct data entered",
      data: ctx.form
    };
    var hashedPassword = bcrypt.hashSync(ctx.request.body.password, 10);
    console.log(hashedPassword);
    console.log(ctx.request.body.email);
    const temp=new User()
    temp.email=ctx.request.body.email
    temp.password=hashedPassword
    await temp.save()
    .then(data=>{
      ctx.body=data
    })
    .catch(err=>{
      ctx.body='error: ' + err
    })
  }
);
